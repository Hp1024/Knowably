***********Knowably***********

Run ```mvn clean compile package``` to package the service
This service is used to register and login the user into the system using JwtAuthorization token.

When a user register, user information is stored in mysql Database