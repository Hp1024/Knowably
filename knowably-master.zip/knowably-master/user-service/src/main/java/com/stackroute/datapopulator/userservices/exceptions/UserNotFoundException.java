package com.stackroute.datapopulator.userservices.exceptions;

public class UserNotFoundException extends UserException {
    public UserNotFoundException(String msg) {
        super(msg);
    }
}
