package com.stackroute.nlpmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaClient
public class NlpMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NlpMicroserviceApplication.class, args);
	}

}
