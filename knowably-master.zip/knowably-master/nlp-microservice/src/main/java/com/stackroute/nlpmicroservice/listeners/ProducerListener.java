package com.stackroute.nlpmicroservice.listeners;

public class ProducerListener {
}
