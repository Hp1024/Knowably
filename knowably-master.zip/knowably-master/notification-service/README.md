***********Knowably***********

Run ```mvn clean compile package``` to package the service

This service will open a socket whenever a user searches any query and sends back the result to the UI whenever it consumes data from a kafka topic.