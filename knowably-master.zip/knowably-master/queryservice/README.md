***********Knowably***********

Run ```mvn clean compile package``` to package the service

It takes the Query from the user and stores in mongo Db cache.

It perform nlp on the query and restructured that and sends it to result-fetcher service.
