***********Knowably***********

Run ```mvn clean compile package``` to package wiki-scrapper-movie-service

This service is scrapping data from wikipedia page of any movie and converted that into required JSON object.
