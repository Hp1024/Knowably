## Requirements

1. Java - 1.8.x

2. Maven - 3.x.x

3. MySQL - 5.x.x
