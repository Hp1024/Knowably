package com.stackroute.datapopulator.domain;

import java.util.List;
import java.util.Map;

public class InfoModel {
    private List<Map> info;

    public List<Map> getInfo() {
        return info;
    }

    public void setInfo(List<Map> info) {
        this.info = info;
    }
}
