package com.stackroute.datapopulator.datapopulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataPopulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
