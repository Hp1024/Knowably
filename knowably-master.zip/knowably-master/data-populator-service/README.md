***********Knowably***********

Run ```mvn clean compile package``` to package the service

This service is consuming the data from kafka and populating it in Neo4j Db.