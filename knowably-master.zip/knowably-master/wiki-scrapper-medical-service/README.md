***********Knowably***********

Run ```mvn clean compile package``` to package wiki-scrapper-medical-service

This service is scrapping data from wikipedia page of any disease and converted that into required JSON object.
