# WebCrawlerService

WebCrawler is a web search engine, and is the oldest surviving search engine on the web today. For many years, it operated as a metasearch engine. WebCrawler was the first web search engine to provide full text search.

1.Consume Data(JsonObject Input) from Kafka topic TopicTest which is produced by Google-search-service.
2.Publish the result(Json Object WebCrawl) to the topic Topic Payload.


