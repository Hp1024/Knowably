***********Knowably***********

Run ```mvn clean compile package``` to package the service
This service is used to add external apoc library to neo4j