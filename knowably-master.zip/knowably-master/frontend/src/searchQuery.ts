export class searchQuery{
    searchTerm: string;
    domain:string
}
