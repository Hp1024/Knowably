export class analyticsgraph{
    movPosResp: number;
    movNegResp: number;
    medPosResp: number;
    medNegResp: number;
    movAcc: number;
    medAcc: number;
}