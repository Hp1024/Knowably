import { analyticskey } from './analyticskey';

export class analytics{
    key: analyticskey;
    result: string;
}