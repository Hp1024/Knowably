export class expertDTO{
    userId:String;
    domain: String;
    concept: String[];
}