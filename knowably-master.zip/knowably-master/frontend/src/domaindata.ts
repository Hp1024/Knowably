export class domaindata{
    type:string;
    value:string[];
    key:string;

}