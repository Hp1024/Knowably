export class expertInput{
    domain: string;
    concept: string[]
}