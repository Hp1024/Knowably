export class analyticskey{
    query: string;
    domain: string;
    posResponse: number;
    negResponse: number;
}