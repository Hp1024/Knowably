export class UserResultResponse{
    query: string;
    result: string;
    response:string;
    domain:string;
}